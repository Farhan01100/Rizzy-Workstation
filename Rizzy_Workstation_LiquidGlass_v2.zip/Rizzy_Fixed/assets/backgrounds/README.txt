Place your test.png and other backgrounds in assets/backgrounds/
