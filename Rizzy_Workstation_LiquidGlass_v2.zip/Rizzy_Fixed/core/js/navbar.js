/*
 * Rizzy Workstation
 * Navbar Module
 * Version: 1.0.0
 *
 * Floating left liquid-glass vertical navbar.
 * Reads the central application registry and user preferences.
 * Does NOT duplicate application metadata.
 */

window.Navbar = (function () {

    var STORAGE_KEY_SLOTS = "rizzy_navbar_slots";
    var STORAGE_KEY_ORDER = "rizzy_navbar_order";

    var DEFAULT_SLOTS = 4;
    var MAX_SLOTS = 6;
    var MIN_SLOTS = 4;

    var navbarEl = null;
    var slotsContainer = null;
    var aiButton = null;

    /**
     * Read preferred number of slots from localStorage.
     */
    function getSlotCount() {
        try {
            var stored = localStorage.getItem(STORAGE_KEY_SLOTS);
            if (stored !== null) {
                var n = parseInt(stored, 10);
                if (!isNaN(n) && n >= MIN_SLOTS && n <= MAX_SLOTS) {
                    return n;
                }
            }
        } catch (e) { /* ignore */ }
        return DEFAULT_SLOTS;
    }

    /**
     * Persist slot count.
     */
    function setSlotCount(count) {
        count = Math.max(MIN_SLOTS, Math.min(MAX_SLOTS, parseInt(count, 10) || DEFAULT_SLOTS));
        try {
            localStorage.setItem(STORAGE_KEY_SLOTS, String(count));
        } catch (e) { /* ignore */ }
        return count;
    }

    /**
     * Read user-defined application order (array of app ids).
     */
    function getUserOrder() {
        try {
            var raw = localStorage.getItem(STORAGE_KEY_ORDER);
            if (raw) {
                var parsed = JSON.parse(raw);
                if (Array.isArray(parsed)) {
                    return parsed;
                }
            }
        } catch (e) { /* ignore */ }
        return null;
    }

    /**
     * Persist user application order.
     */
    function setUserOrder(order) {
        if (!Array.isArray(order)) return;
        try {
            localStorage.setItem(STORAGE_KEY_ORDER, JSON.stringify(order));
        } catch (e) { /* ignore */ }
    }

    /**
     * Build the ordered list of applications that should appear
     * in the navbar slots, respecting:
     *  - navbar.enabled
     *  - user order / selection
     *  - default apps when no preference exists
     *  - slot count limit
     */
    function resolveSlotApps() {
        if (typeof AppLoader === "undefined") {
            return [];
        }

        var eligible = AppLoader.getNavbarEligibleApps();
        var slotCount = getSlotCount();
        var userOrder = getUserOrder();

        var selected = [];

        if (userOrder && userOrder.length > 0) {
            // Honour explicit user selection & order
            for (var i = 0; i < userOrder.length && selected.length < slotCount; i++) {
                var id = userOrder[i];
                var app = AppLoader.getApp(id);
                if (app && app.navbar && app.navbar.enabled) {
                    selected.push(app);
                }
            }
        }

        // If still under capacity, fill with default apps then remaining eligible
        if (selected.length < slotCount) {
            var already = {};
            selected.forEach(function (a) { already[a.id] = true; });

            // Prefer apps marked navbar.default
            var defaults = eligible.filter(function (a) {
                return a.navbar.default && !already[a.id];
            });
            for (var d = 0; d < defaults.length && selected.length < slotCount; d++) {
                selected.push(defaults[d]);
                already[defaults[d].id] = true;
            }

            // Then any remaining eligible
            for (var e = 0; e < eligible.length && selected.length < slotCount; e++) {
                if (!already[eligible[e].id]) {
                    selected.push(eligible[e]);
                    already[eligible[e].id] = true;
                }
            }
        }

        return selected.slice(0, slotCount);
    }

    /**
     * Create a single navbar slot button for an application.
     */
    function createSlotButton(app) {
        var btn = document.createElement("button");
        btn.type = "button";
        btn.className = "navbar-slot";
        btn.setAttribute("data-app-id", app.id);
        btn.title = app.name || app.id;

        if (app.iconUrl) {
            var img = document.createElement("img");
            img.src = app.iconUrl;
            img.alt = app.name || "";
            img.className = "navbar-slot-icon";
            img.onerror = function () {
                // Fallback to first letter
                this.style.display = "none";
                var fallback = document.createElement("span");
                fallback.className = "navbar-slot-fallback";
                fallback.textContent = (app.name || app.id || "?").charAt(0).toUpperCase();
                btn.appendChild(fallback);
            };
            btn.appendChild(img);
        } else {
            var span = document.createElement("span");
            span.className = "navbar-slot-fallback";
            span.textContent = (app.name || app.id || "?").charAt(0).toUpperCase();
            btn.appendChild(span);
        }

        btn.addEventListener("click", function () {
            openApplication(app);
        });

        return btn;
    }

    /**
     * Open an application through AppRenderer.
     */
    function openApplication(app) {
        if (!app || !app.url) {
            console.warn("Navbar: Cannot open invalid application", app);
            return;
        }

        var container = document.getElementById("app-container");
        if (!container) {
            console.error("Navbar: Application container not found");
            return;
        }

        if (typeof AppRenderer !== "undefined") {
            AppRenderer.renderApp(app, container);
        } else {
            console.error("Navbar: AppRenderer is not available");
        }
    }

    /**
     * Render / re-render all application slots.
     */
    function renderSlots() {
        if (!slotsContainer) return;

        slotsContainer.innerHTML = "";
        var apps = resolveSlotApps();

        apps.forEach(function (app) {
            slotsContainer.appendChild(createSlotButton(app));
        });
    }

    /**
     * Build the full navbar DOM structure.
     */
    function buildNavbar() {
        navbarEl = document.getElementById("floating-navbar");
        if (!navbarEl) {
            console.error("Navbar: #floating-navbar element not found");
            return;
        }

        navbarEl.innerHTML = "";

        // Application slots container
        slotsContainer = document.createElement("div");
        slotsContainer.className = "navbar-slots";
        navbarEl.appendChild(slotsContainer);

        // Divider
        var divider = document.createElement("div");
        divider.className = "navbar-divider";
        navbarEl.appendChild(divider);

        // AI / Search button
        aiButton = document.createElement("button");
        aiButton.type = "button";
        aiButton.className = "navbar-ai-button";
        aiButton.id = "navbarAiButton";
        aiButton.title = "Search";
        aiButton.innerHTML = "✦";
        navbarEl.appendChild(aiButton);

        aiButton.addEventListener("click", function () {
            if (typeof SearchUI !== "undefined" && SearchUI.toggle) {
                SearchUI.toggle();
            } else {
                console.warn("Navbar: SearchUI not available");
            }
        });

        renderSlots();
    }

    /**
     * Public refresh – call after settings change or app scan.
     */
    function refresh() {
        renderSlots();
    }

    /**
     * Initialize the navbar.
     */
    function init() {
        buildNavbar();
    }

    // Expose preference helpers for Settings integration
    return {
        init: init,
        refresh: refresh,
        getSlotCount: getSlotCount,
        setSlotCount: setSlotCount,
        getUserOrder: getUserOrder,
        setUserOrder: setUserOrder,
        resolveSlotApps: resolveSlotApps,
        openApplication: openApplication,
        MIN_SLOTS: MIN_SLOTS,
        MAX_SLOTS: MAX_SLOTS,
        DEFAULT_SLOTS: DEFAULT_SLOTS
    };

})();
