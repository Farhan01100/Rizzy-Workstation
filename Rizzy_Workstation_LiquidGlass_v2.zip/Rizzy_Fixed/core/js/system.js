/*
========================================
RIZZY WORKSTATION
SYSTEM CONTROLLER
Version: 1.1.0
========================================
*/

window.System = (function () {

    var settingsPanel = null;

    /* SYSTEM INITIALIZATION */

    function initializeSystem() {
        console.log("Rizzy Workstation started.");

        // Search UI can be initialized early (lazy DOM)
        if (typeof SearchUI !== "undefined") {
            SearchUI.init();
        }

        initializeAppSystem();
    }

    /* APP SYSTEM INITIALIZATION */

    async function initializeAppSystem() {
        console.log("Initializing application system...");

        if (typeof AppLoader === "undefined" || typeof AppRenderer === "undefined") {
            console.error("App system scripts are not connected!");
            return;
        }

        console.log("AppLoader connected.");
        console.log("AppRenderer connected.");

        var container = document.getElementById("app-container");
        if (!container) {
            console.error("Application container not found!");
            return;
        }

        try {
            // Scan applications (preserve previous range / exclude logic)
            // app_6 and app_7 have no entry files → will be reported as invalid
            var result = await AppLoader.loadApps({
                from: 1,
                to: 10,
                exclude: [],          // no longer hard-skip; manifests handle eligibility
                include: [],
                basePath: "../apps/"
            });

            window.SystemApps = result;

            console.log("Application scan completed.");
            console.log("Total checked:", result.totalChecked);
            console.log("Available:", result.available.length);
            console.log("Missing:", result.missing.length);
            console.log("Invalid:", result.invalid ? result.invalid.length : 0);
            console.log("Skipped:", result.skipped.length);
            console.log("Errors:", result.errors.length);

            // Initialize navbar after registry is populated
            if (typeof Navbar !== "undefined") {
                Navbar.init();
                console.log("Navbar initialized.");
            } else {
                console.error("Navbar module not found.");
            }

            // Prepare settings UI (basic for now)
            prepareSettings();

            console.log("Application system initialized.");

        } catch (error) {
            console.error("Application initialization failed:", error);
        }
    }

    /* SETTINGS (prepared for navbar slot / order configuration) */

    function prepareSettings() {
        // Create a simple settings panel if it does not exist
        settingsPanel = document.getElementById("settings-panel");
        if (!settingsPanel) {
            settingsPanel = document.createElement("div");
            settingsPanel.id = "settings-panel";
            settingsPanel.className = "settings-panel";
            document.querySelector(".desktop").appendChild(settingsPanel);
        }

        renderSettingsContent();
    }

    function renderSettingsContent() {
        if (!settingsPanel) return;

        var slotCount = (typeof Navbar !== "undefined")
            ? Navbar.getSlotCount()
            : 4;

        var html = "";
        html += "<h3>Settings</h3>";

        // Slot count
        html += "<div class=\"setting-group\">";
        html += "<label class=\"setting-label\">Navbar slots</label>";
        html += "<div class=\"setting-slots\">";
        for (var s = 4; s <= 6; s++) {
            var active = (s === slotCount) ? " active" : "";
            html += "<button type=\"button\" class=\"slot-count-btn" + active +
                "\" data-slots=\"" + s + "\">" + s + "</button>";
        }
        html += "</div></div>";

        // App order / selection
        html += "<div class=\"setting-group\">";
        html += "<label class=\"setting-label\">Navbar applications</label>";
        html += "<p class=\"setting-hint\">Select up to " + slotCount +
            " apps. Drag order is preserved by selection order.</p>";
        html += "<div class=\"setting-app-list\" id=\"settings-app-list\"></div>";
        html += "</div>";

        html += "<button type=\"button\" class=\"settings-close-btn\" id=\"settingsCloseBtn\">Close</button>";

        settingsPanel.innerHTML = html;

        // Wire slot buttons
        var slotBtns = settingsPanel.querySelectorAll(".slot-count-btn");
        for (var i = 0; i < slotBtns.length; i++) {
            slotBtns[i].addEventListener("click", function () {
                var n = parseInt(this.getAttribute("data-slots"), 10);
                if (typeof Navbar !== "undefined") {
                    Navbar.setSlotCount(n);
                    // Trim user order if necessary
                    var order = Navbar.getUserOrder() || [];
                    if (order.length > n) {
                        Navbar.setUserOrder(order.slice(0, n));
                    }
                    Navbar.refresh();
                }
                renderSettingsContent(); // re-render to reflect new limit
            });
        }

        // Populate app checklist
        populateAppChecklist(slotCount);

        // Close button
        var closeBtn = document.getElementById("settingsCloseBtn");
        if (closeBtn) {
            closeBtn.addEventListener("click", closeSettings);
        }
    }

    function populateAppChecklist(slotCount) {
        var listEl = document.getElementById("settings-app-list");
        if (!listEl || typeof AppLoader === "undefined") return;

        listEl.innerHTML = "";
        var eligible = AppLoader.getNavbarEligibleApps();
        var currentOrder = (typeof Navbar !== "undefined")
            ? (Navbar.getUserOrder() || [])
            : [];

        // If no user order yet, seed with current resolved slots
        if (currentOrder.length === 0 && typeof Navbar !== "undefined") {
            currentOrder = Navbar.resolveSlotApps().map(function (a) { return a.id; });
        }

        eligible.forEach(function (app) {
            var row = document.createElement("label");
            row.className = "setting-app-row";

            var cb = document.createElement("input");
            cb.type = "checkbox";
            cb.value = app.id;
            cb.checked = currentOrder.indexOf(app.id) !== -1;

            cb.addEventListener("change", function () {
                updateOrderFromCheckboxes(slotCount);
            });

            var name = document.createElement("span");
            name.textContent = app.name;

            row.appendChild(cb);
            row.appendChild(name);
            listEl.appendChild(row);
        });
    }

    function updateOrderFromCheckboxes(slotCount) {
        var listEl = document.getElementById("settings-app-list");
        if (!listEl || typeof Navbar === "undefined") return;

        var checked = [];
        var boxes = listEl.querySelectorAll("input[type=checkbox]");
        for (var i = 0; i < boxes.length; i++) {
            if (boxes[i].checked) {
                checked.push(boxes[i].value);
            }
        }

        // Limit to slotCount (uncheck extras from the end)
        if (checked.length > slotCount) {
            var excess = checked.splice(slotCount);
            for (var e = 0; e < excess.length; e++) {
                for (var b = 0; b < boxes.length; b++) {
                    if (boxes[b].value === excess[e]) {
                        boxes[b].checked = false;
                    }
                }
            }
        }

        Navbar.setUserOrder(checked);
        Navbar.refresh();
    }

    function openSettings() {
        if (!settingsPanel) prepareSettings();
        renderSettingsContent();
        settingsPanel.classList.add("active");
    }

    function closeSettings() {
        if (settingsPanel) {
            settingsPanel.classList.remove("active");
        }
    }

    function toggleSettings() {
        if (settingsPanel && settingsPanel.classList.contains("active")) {
            closeSettings();
        } else {
            openSettings();
        }
    }

    /* PUBLIC API */

    return {
        initializeSystem: initializeSystem,
        openSettings: openSettings,
        closeSettings: closeSettings,
        toggleSettings: toggleSettings
    };

})();


/* START SYSTEM */

document.addEventListener("DOMContentLoaded", function () {
    System.initializeSystem();
});
