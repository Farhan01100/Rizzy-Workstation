/*
 * Rizzy Workstation
 * App Loader
 * Version: 1.1.0
 *
 * Discovers applications, reads and validates their manifests,
 * resolves paths, and maintains a central application registry.
 */

window.AppLoader = (function () {

    // Central registry of valid applications (keyed by id)
    var registry = {};

    // Scan results for diagnostics
    var lastScan = null;

    /**
     * Required top-level fields in a valid manifest.
     */
    var REQUIRED_FIELDS = ["id", "name", "version", "entry", "icon"];

    /**
     * Validate that a parsed manifest object has the required fields.
     * Returns an error string or null if valid.
     */
    function validateManifest(manifest, appFolderId) {
        if (!manifest || typeof manifest !== "object") {
            return "Manifest is not a valid object";
        }

        for (var i = 0; i < REQUIRED_FIELDS.length; i++) {
            var field = REQUIRED_FIELDS[i];
            if (!manifest[field] || typeof manifest[field] !== "string") {
                return "Missing or invalid required field: " + field;
            }
        }

        // id should match the folder name when possible (soft check)
        if (manifest.id && appFolderId && manifest.id !== appFolderId) {
            console.warn(
                "Manifest id \"" + manifest.id +
                "\" does not match folder \"" + appFolderId + "\""
            );
        }

        // navbar block is optional but if present should be an object
        if (manifest.navbar !== undefined &&
            (typeof manifest.navbar !== "object" || manifest.navbar === null)) {
            return "Invalid navbar property";
        }

        return null;
    }

    /**
     * Resolve a path relative to the application root.
     * Ensures no leading slash and normalizes simple relative paths.
     */
    function resolvePath(appRoot, relativePath) {
        if (!relativePath) {
            return null;
        }
        // Strip leading ./ or /
        var clean = relativePath.replace(/^\.?\/+/, "");
        return appRoot + clean;
    }

    /**
     * Check whether a resource exists via HEAD/GET.
     */
    async function resourceExists(url) {
        try {
            var response = await fetch(url, {
                method: "GET",
                cache: "no-store"
            });

            if (!response.ok) {
                return false;
            }

            // Drain body if present to avoid memory leaks
            if (response.body) {
                try {
                    await response.body.cancel();
                } catch (e) { /* ignore */ }
            }

            return true;
        } catch (error) {
            return false;
        }
    }

    /**
     * Load and validate a single application's manifest.
     * Returns a normalized application object or a status descriptor.
     */
    async function loadSingleApp(folderId, basePath) {
        var appRoot = basePath + folderId + "/";
        var manifestUrl = appRoot + "manifest.json";

        var result = {
            id: folderId,
            folderId: folderId,
            status: "unknown",
            manifest: null,
            url: null,
            iconUrl: null,
            name: null,
            description: null,
            category: null,
            navbar: null,
            error: null
        };

        // 1. Fetch manifest
        var manifestText;
        try {
            var response = await fetch(manifestUrl, {
                method: "GET",
                cache: "no-store"
            });

            if (!response.ok) {
                result.status = "missing";
                result.error = "manifest.json not found (HTTP " + response.status + ")";
                return result;
            }

            manifestText = await response.text();
        } catch (error) {
            result.status = "error";
            result.error = "Failed to fetch manifest: " + error.message;
            return result;
        }

        // 2. Parse JSON
        var manifest;
        try {
            manifest = JSON.parse(manifestText);
        } catch (error) {
            result.status = "invalid";
            result.error = "Invalid JSON in manifest: " + error.message;
            return result;
        }

        // 3. Validate required fields
        var validationError = validateManifest(manifest, folderId);
        if (validationError) {
            result.status = "invalid";
            result.error = validationError;
            result.manifest = manifest;
            return result;
        }

        // 4. Resolve entry and icon paths
        var entryUrl = resolvePath(appRoot, manifest.entry);
        var iconUrl = resolvePath(appRoot, manifest.icon);

        // 5. Verify entry file exists
        var entryExists = await resourceExists(entryUrl);
        if (!entryExists) {
            result.status = "invalid";
            result.error = "Entry file does not exist: " + manifest.entry;
            result.manifest = manifest;
            result.url = entryUrl;
            return result;
        }

        // 6. Icon is optional at runtime – we still record the path
        //    Missing icons are handled gracefully by the navbar.
        var iconExists = await resourceExists(iconUrl);

        // 7. Build normalized application object
        result.status = "available";
        result.manifest = manifest;
        result.url = entryUrl;
        result.iconUrl = iconExists ? iconUrl : null;
        result.name = manifest.name;
        result.description = manifest.description || "";
        result.category = manifest.category || "utility";
        result.version = manifest.version;
        result.navbar = {
            enabled: !!(manifest.navbar && manifest.navbar.enabled !== false),
            default: !!(manifest.navbar && manifest.navbar.default === true)
        };
        result.permissions = Array.isArray(manifest.permissions)
            ? manifest.permissions
            : [];

        return result;
    }

    /**
     * Discover and load applications.
     *
     * Options (compatible with previous API):
     *   from, to      – numeric range of app_N folders
     *   include       – extra numeric ids to force-include
     *   exclude       – numeric ids to skip (unless in include)
     *   basePath      – path to apps directory (default "../apps/")
     *   folders       – optional explicit list of folder names (overrides range)
     */
    async function loadApps(options) {
        options = options || {};

        var from = options.from != null ? options.from : 1;
        var to = options.to != null ? options.to : 20;
        var basePath = options.basePath || "../apps/";
        var exclude = options.exclude || [];
        var include = options.include || [];
        var explicitFolders = options.folders || null;

        var results = [];
        var folderIds = [];

        if (explicitFolders && Array.isArray(explicitFolders)) {
            folderIds = explicitFolders.slice();
        } else {
            var idSet = {};
            for (var i = from; i <= to; i++) {
                idSet[i] = true;
            }
            include.forEach(function (id) {
                idSet[id] = true;
            });

            Object.keys(idSet).forEach(function (key) {
                var num = parseInt(key, 10);
                if (exclude.indexOf(num) !== -1 && include.indexOf(num) === -1) {
                    results.push({
                        id: "app_" + num,
                        folderId: "app_" + num,
                        status: "skipped"
                    });
                } else {
                    folderIds.push("app_" + num);
                }
            });
        }

        // Load each candidate
        for (var f = 0; f < folderIds.length; f++) {
            var folderId = folderIds[f];
            var appResult = await loadSingleApp(folderId, basePath);
            results.push(appResult);

            // Populate central registry only for available apps
            if (appResult.status === "available") {
                registry[appResult.id] = appResult;
            }
        }

        lastScan = {
            totalChecked: results.length,
            available: results.filter(function (a) { return a.status === "available"; }),
            missing: results.filter(function (a) { return a.status === "missing"; }),
            invalid: results.filter(function (a) { return a.status === "invalid"; }),
            skipped: results.filter(function (a) { return a.status === "skipped"; }),
            errors: results.filter(function (a) { return a.status === "error"; }),
            results: results
        };

        return lastScan;
    }

    /**
     * Return the current application registry (available apps only).
     */
    function getRegistry() {
        return registry;
    }

    /**
     * Get a single application by id.
     */
    function getApp(id) {
        return registry[id] || null;
    }

    /**
     * Return all available applications as an array.
     */
    function getAvailableApps() {
        return Object.keys(registry).map(function (key) {
            return registry[key];
        });
    }

    /**
     * Apps that are eligible for the navbar (navbar.enabled === true).
     */
    function getNavbarEligibleApps() {
        return getAvailableApps().filter(function (app) {
            return app.navbar && app.navbar.enabled;
        });
    }

    /**
     * Last scan diagnostic data.
     */
    function getLastScan() {
        return lastScan;
    }

    /**
     * Clear the registry (useful for re-scans).
     */
    function clearRegistry() {
        registry = {};
        lastScan = null;
    }

    return {
        loadApps: loadApps,
        getRegistry: getRegistry,
        getApp: getApp,
        getAvailableApps: getAvailableApps,
        getNavbarEligibleApps: getNavbarEligibleApps,
        getLastScan: getLastScan,
        clearRegistry: clearRegistry
    };

})();
