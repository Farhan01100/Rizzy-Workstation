/*
 * Rizzy Workstation
 * Search Interface
 * Version: 1.0.0
 *
 * Floating liquid-glass search UI.
 * This is a NORMAL search bar (not an AI agent).
 * Searches installed applications and basic workstation features.
 */

window.SearchUI = (function () {

    var overlay = null;
    var panel = null;
    var input = null;
    var resultsEl = null;
    var isOpen = false;

    /**
     * Built-in feature suggestions (workstation capabilities).
     */
    var FEATURES = [
        { id: "feature_close", name: "Close Application", type: "feature", action: "closeApp" },
        { id: "feature_settings", name: "Settings", type: "feature", action: "openSettings" }
    ];

    function createDOM() {
        // Overlay (click to close)
        overlay = document.createElement("div");
        overlay.id = "search-overlay";
        overlay.className = "search-overlay";
        overlay.addEventListener("click", function (e) {
            if (e.target === overlay) {
                close();
            }
        });

        // Main panel
        panel = document.createElement("div");
        panel.className = "search-panel";
        panel.id = "search-panel";

        // Results list (above input)
        resultsEl = document.createElement("div");
        resultsEl.className = "search-results";
        resultsEl.id = "search-results";
        panel.appendChild(resultsEl);

        // Input row
        var inputRow = document.createElement("div");
        inputRow.className = "search-input-row";

        input = document.createElement("input");
        input.type = "text";
        input.id = "search-input";
        input.className = "search-input";
        input.placeholder = "Search apps and features...";
        input.autocomplete = "off";
        input.spellcheck = false;
        input.setAttribute("enterkeyhint", "search");

        input.addEventListener("input", onInput);
        input.addEventListener("keydown", onKeyDown);

        inputRow.appendChild(input);
        panel.appendChild(inputRow);

        overlay.appendChild(panel);
        document.body.appendChild(overlay);
    }

    function onInput() {
        var query = (input.value || "").trim().toLowerCase();
        renderResults(query);
    }

    function onKeyDown(e) {
        if (e.key === "Escape") {
            close();
            return;
        }
        if (e.key === "Enter") {
            var first = resultsEl.querySelector(".search-result-item");
            if (first) {
                first.click();
            }
        }
    }

    /**
     * Gather searchable items: apps + features.
     */
    function getSearchableItems() {
        var items = [];

        if (typeof AppLoader !== "undefined") {
            var apps = AppLoader.getAvailableApps();
            apps.forEach(function (app) {
                items.push({
                    id: app.id,
                    name: app.name,
                    description: app.description || "",
                    type: "app",
                    app: app
                });
            });
        }

        FEATURES.forEach(function (f) {
            items.push(f);
        });

        return items;
    }

    function filterItems(query) {
        var items = getSearchableItems();
        if (!query) {
            // Show a short list of apps by default
            return items.filter(function (i) { return i.type === "app"; }).slice(0, 8);
        }

        return items.filter(function (item) {
            var hay = (item.name + " " + (item.description || "")).toLowerCase();
            return hay.indexOf(query) !== -1;
        }).slice(0, 12);
    }

    function renderResults(query) {
        resultsEl.innerHTML = "";
        var matches = filterItems(query);

        if (matches.length === 0) {
            var empty = document.createElement("div");
            empty.className = "search-empty";
            empty.textContent = query ? "No matches found" : "Type to search applications";
            resultsEl.appendChild(empty);
            return;
        }

        matches.forEach(function (item) {
            var row = document.createElement("button");
            row.type = "button";
            row.className = "search-result-item";
            row.setAttribute("data-type", item.type);

            var iconSpan = document.createElement("span");
            iconSpan.className = "search-result-icon";

            if (item.type === "app" && item.app && item.app.iconUrl) {
                var img = document.createElement("img");
                img.src = item.app.iconUrl;
                img.alt = "";
                img.onerror = function () {
                    this.style.display = "none";
                    iconSpan.textContent = (item.name || "?").charAt(0).toUpperCase();
                };
                iconSpan.appendChild(img);
            } else if (item.type === "feature") {
                iconSpan.textContent = "⚙️";
            } else {
                iconSpan.textContent = (item.name || "?").charAt(0).toUpperCase();
            }

            var textWrap = document.createElement("div");
            textWrap.className = "search-result-text";

            var title = document.createElement("div");
            title.className = "search-result-title";
            title.textContent = item.name;

            var sub = document.createElement("div");
            sub.className = "search-result-sub";
            sub.textContent = item.type === "app"
                ? (item.description || "Application")
                : "Workstation feature";

            textWrap.appendChild(title);
            textWrap.appendChild(sub);

            row.appendChild(iconSpan);
            row.appendChild(textWrap);

            row.addEventListener("click", function () {
                selectResult(item);
            });

            resultsEl.appendChild(row);
        });
    }

    function selectResult(item) {
        close();

        if (item.type === "app" && item.app) {
            if (typeof Navbar !== "undefined" && Navbar.openApplication) {
                Navbar.openApplication(item.app);
            } else if (typeof AppRenderer !== "undefined") {
                var container = document.getElementById("app-container");
                if (container) {
                    AppRenderer.renderApp(item.app, container);
                }
            }
            return;
        }

        if (item.type === "feature") {
            if (item.action === "closeApp") {
                var container = document.getElementById("app-container");
                if (container && typeof AppRenderer !== "undefined") {
                    AppRenderer.closeApp(container);
                }
            } else if (item.action === "openSettings") {
                if (typeof System !== "undefined" && System.openSettings) {
                    System.openSettings();
                } else {
                    console.log("Settings requested (not yet fully implemented)");
                }
            }
        }
    }

    function open() {
        if (!overlay) createDOM();
        isOpen = true;
        overlay.classList.add("active");
        panel.classList.add("active");
        renderResults("");
        // Focus after animation frame so mobile keyboard adapts
        setTimeout(function () {
            if (input) {
                input.value = "";
                input.focus();
            }
        }, 60);
    }

    function close() {
        isOpen = false;
        if (overlay) {
            overlay.classList.remove("active");
        }
        if (panel) {
            panel.classList.remove("active");
        }
        if (input) {
            input.blur();
            input.value = "";
        }
    }

    function toggle() {
        if (isOpen) {
            close();
        } else {
            open();
        }
    }

    function init() {
        // DOM is created lazily on first open
    }

    return {
        init: init,
        open: open,
        close: close,
        toggle: toggle,
        isOpen: function () { return isOpen; }
    };

})();
