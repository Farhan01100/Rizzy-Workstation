/*
 * Rizzy Workstation
 * App Renderer
 * Version: 1.1.0
 *
 * Renders applications inside the main application container
 * using an iframe. Uses manifest entry path and application name.
 */

window.AppRenderer = (function () {

    var currentAppId = null;

    /**
     * Render an application into the given container.
     *
     * @param {Object} app - Application object from the registry
     *        (must have at least .url and preferably .name / .id)
     * @param {HTMLElement} container - Target container element
     * @param {Object} [options] - Optional overrides (title, etc.)
     * @returns {HTMLIFrameElement|null}
     */
    function renderApp(app, container, options) {
        options = options || {};

        if (!app || !app.url) {
            console.error("AppRenderer: Invalid application object (missing url).");
            return null;
        }

        if (!container) {
            console.error("AppRenderer: Application container not found.");
            return null;
        }

        // Clear previous application
        container.innerHTML = "";
        currentAppId = app.id || null;

        // Create application frame
        var iframe = document.createElement("iframe");
        iframe.src = app.url;
        iframe.title = options.title || app.name || ("Rizzy App " + (app.id || ""));
        iframe.setAttribute("data-app-id", app.id || "");
        iframe.style.width = "100%";
        iframe.style.height = "100%";
        iframe.style.border = "none";
        iframe.allowFullscreen = true;

        // Basic error handling for failed loads
        iframe.onerror = function () {
            console.error("AppRenderer: Failed to load application iframe for", app.id);
        };

        container.appendChild(iframe);
        container.style.display = "block";

        return iframe;
    }

    /**
     * Close the currently open application and hide the container.
     */
    function closeApp(container) {
        if (container) {
            container.innerHTML = "";
            container.style.display = "none";
        }
        currentAppId = null;
    }

    /**
     * Return the id of the currently open application (or null).
     */
    function getCurrentAppId() {
        return currentAppId;
    }

    return {
        renderApp: renderApp,
        closeApp: closeApp,
        getCurrentAppId: getCurrentAppId
    };

})();
