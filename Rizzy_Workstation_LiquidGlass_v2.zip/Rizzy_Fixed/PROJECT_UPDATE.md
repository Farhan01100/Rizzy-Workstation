# Rizzy Workstation — Project Update (v1.1)

## Updated Folder Structure

```
Rizzy Workstation/
├── apps/
│   ├── app_1/
│   │   ├── manifest.json          ← NEW
│   │   ├── index.html
│   │   └── assets/
│   │       └── icon.png           ← NEW (placeholder)
│   ├── app_2/ … app_5/            (same pattern)
│   ├── app_6/                     (manifest only – no entry → invalid)
│   ├── app_7/                     (manifest only – no entry → invalid)
│   ├── app_8/ … app_10/
├── assets/
├── assets1/
├── components/
├── core/
│   ├── css/
│   │   └── system.css             ← UPDATED
│   ├── js/
│   │   ├── app_loader.js          ← UPDATED
│   │   ├── app_renderer.js        ← UPDATED
│   │   ├── navbar.js              ← NEW
│   │   ├── search.js              ← NEW
│   │   └── system.js              ← UPDATED
│   └── system.html                ← UPDATED
├── services/
└── PROJECT_UPDATE.md             ← this file
```

## Modified Files
- `core/system.html`
- `core/css/system.css`
- `core/js/app_loader.js`
- `core/js/app_renderer.js`
- `core/js/system.js`

## Newly Created Files
- `core/js/navbar.js`
- `core/js/search.js`
- `apps/app_*/manifest.json` (for app_1 … app_10)
- `apps/app_*/assets/icon.png` (placeholder icons for available apps)
- `PROJECT_UPDATE.md`

---

## Application Manifest System

Every application now lives in its own directory under `apps/` and **must** contain a `manifest.json` at its root.

### Schema (initial)

```json
{
  "id": "app_1",
  "name": "Welcome",
  "version": "1.0.0",
  "description": "…",
  "entry": "index.html",
  "icon": "assets/icon.png",
  "category": "utility",
  "navbar": {
    "enabled": true,
    "default": true
  },
  "permissions": []
}
```

- All paths inside the manifest are **relative to the application root**.
- Required fields: `id`, `name`, `version`, `entry`, `icon`.
- `navbar.enabled` controls eligibility for the left navbar.
- `navbar.default` marks apps that appear in the default 4-slot set when the user has not customised the order.
- The schema is deliberately open for future properties (dependencies, min workstation version, window behaviour, update info, etc.).

### Loader behaviour (`AppLoader`)

1. Scans the configured range of `app_N` folders (still supports `from`/`to`/`include`/`exclude`).
2. Fetches and parses each `manifest.json`.
3. Validates required fields.
4. Resolves `entry` and `icon` paths relative to the app root.
5. Confirms the entry file actually exists.
6. Stores only **available** applications in a central registry (`AppLoader.getRegistry()`).
7. Reports `available`, `missing`, `invalid`, `skipped` and `errors` separately – a broken manifest never crashes the workstation.

---

## Navbar Application Selection

- Default slot count: **4** (configurable to 5 or 6 via Settings / localStorage).
- Only applications with `navbar.enabled === true` are eligible.
- User preferences are stored in `localStorage`:
  - `rizzy_navbar_slots` – number of slots (4–6)
  - `rizzy_navbar_order` – ordered array of application ids
- When no user order exists, apps marked `navbar.default: true` are preferred, then any remaining eligible apps.
- The AI / Search icon is **separate** from the application slots and sits under a divider.
- Clicking the AI icon opens the **normal search interface** (not an AI agent).

### Settings integration (prepared)

- Open Settings from the search results (“Settings” feature) or by calling `System.openSettings()`.
- Users can:
  - Choose 4, 5 or 6 navbar slots
  - Select which eligible applications appear (checkboxes)
  - Order is determined by the order of selection (first checked = first slot)
- Preferences persist via localStorage; no accounts or server.

---

## Search Interface

- Floating liquid-glass panel near the bottom of the screen.
- Opens from the navbar AI icon.
- Searches installed applications (by name / description) and a couple of workstation features (Close Application, Settings).
- Selecting a result launches the application through `AppRenderer` or performs the feature action.
- Animations and mobile-keyboard-friendly layout (panel sits above the keyboard area).

---

## Theme Compatibility

- No hard-coded Olive Metallic colours in the new components.
- All glass, border, shadow, text and accent values come from CSS custom properties defined on `:root`.
- Future light/dark mode or user themes only need to override these variables.

---

## Known Limitations / Unfinished Functionality

1. **Settings entry point** – there is no dedicated gear button on the navbar yet. Settings is reachable via the Search interface (“Settings” result) or programmatically.
2. **Desktop icons zone** – still reserved; not populated.
3. **App close UI** – applications can be closed via the Search “Close Application” feature; a dedicated close button inside the application chrome is not yet present.
4. **Icon generation** – placeholder letter icons were generated for the existing apps. Real artwork should replace `assets/icon.png` inside each app folder.
5. **Empty apps (app_6, app_7)** – have manifests but no `index.html`, so they correctly appear as `invalid` and never enter the registry or navbar.
6. **Theme switcher / light-dark mode** – intentionally left for a future Settings iteration (as requested).
7. **No ES modules** – all scripts are classic scripts attached via `<script src>`; no `import`/`export`.

---

## How to Run

Serve the project over HTTP (required for `fetch` of manifests):

```bash
# from the project root
npx serve .          # or any static server
# then open /core/system.html
```

Or open `core/system.html` through any local HTTP development environment that maps the project root correctly so that `../apps/` resolves.
